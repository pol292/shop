<div class="col-xs-6 col-sm-4 col-lg-3 box-product-outer">
    <div class="box-product">
        @include('shop.skin.product')
    </div>
</div>