<div class="box-product">
    @include('shop.skin.product')
</div>