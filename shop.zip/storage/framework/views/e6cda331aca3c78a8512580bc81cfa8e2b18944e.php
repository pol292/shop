<div class="col-xs-6 col-sm-4 col-lg-3 box-product-outer">
    <div class="box-product">
        <div class="img-wrapper">
            <a href="<?php echo e(url("shop/{$product['category']['url']}/{$product['url']}")); ?>">
                <img alt="Product" src="<?php echo e(asset("images/up/{$product['image']}")); ?>">
            </a>
            <?php if(!empty($product['sale'])): ?>
            <div class="tags">
                <span class="label-tags">
                    <a href="<?php echo e(url("shop/{$product['category']['url']}/{$product['url']}")); ?>">
                        <span class="label label-default arrowed">-<?php echo e($product['sale']['discount']); ?>%</span>
                    </a>
                </span>
            </div>
            <div class="tags tags-left">
                <span class="label-tags">
                    <a href="<?php echo e(url("shop/{$product['category']['url']}/{$product['url']}")); ?>">
                        <span class="label label-<?php echo e($product['sale']['color']); ?> arrowed-right">Sale</span>
                    </a>
                </span>
            </div>
            <?php endif; ?>
            <div class="option">
                <a href="#" data-toggle="tooltip" title="Add to Cart"><i class="fa fa-shopping-cart"></i></a>
                <a href="#" data-toggle="tooltip" title="Add to Compare"><i class="fa fa-align-left"></i></a>
                <a href="#" data-toggle="tooltip" title="Add to Wishlist" class="wishlist"><i class="fa fa-heart"></i></a>
            </div>
        </div>
        <h6><a href="<?php echo e(url("shop/{$product['category']['url']}/{$product['url']}")); ?>"><?php echo e($product['title']); ?></a></h6>
        <?php if(empty($product['sale'])): ?>
        <div>$<?php echo e($product['price']); ?> </div>
        <?php else: ?>
        <div class="price">
            <div>
                $<?php echo e($product['price']*(1-$product['sale']['discount']/100)); ?> 
                <span class="label-tags">
                    <span class="label label-default">-<?php echo e($product['sale']['discount']); ?>%</span>
                </span>
            </div>
            <span class="price-old">$<?php echo e($product['price']); ?></span>
        </div>
        <?php endif; ?>
        <div class="rating">
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star-half-o"></i>
            <a href="#">(5 reviews)</a>
        </div>
    </div>
</div>