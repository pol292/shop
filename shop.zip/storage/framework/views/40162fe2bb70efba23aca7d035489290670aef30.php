<!--Pagination-->

<?php if(!empty($pagination['count']) && $pagination['count'] > 1): ?>

<?php 
    $query_string =  str_replace("page={$request->page}" , '' , $_SERVER['QUERY_STRING']);
    $query_string = empty($query_string)? '' : '&' . $query_string;
 ?>
<div class="text-center">

    <ul class="pagination">
        <?php if($pagination['active'] != 1): ?>
        <li>
            <a href="<?php echo e($pagination['url'] .'1' . $query_string); ?>"><span>&laquo;</span></span></a>
        </li>
        <li>
            <a href="<?php echo e($pagination['url'] . ($pagination['active'] - 1) . $query_string); ?>"><span>&lsaquo;</span></span></a>
        </li>
        <?php endif; ?>
        <?php if($pagination['active']): ?>

        <?php if($pagination['active'] < 3): ?>
        <?php for($i = 1, $end = (($pagination['count'] > 5)? 5 : $pagination['count']); $i <= $end ; $i++): ?>
        <li <?php if($i == $pagination['active']): ?>class="active"<?php endif; ?>>
             <a href="<?php echo e($pagination['url'].$i. $query_string); ?>"><?php echo e($i); ?></a>
        </li>
        <?php endfor; ?>
        <?php elseif($pagination['active'] >= ($pagination['count'] - 2) ): ?>
        <a href="pagination.blade.php"></a>
        <?php for($i = ($pagination['count'] - 5 > 0)? $pagination['count'] - 5 :1; $i <= $pagination['count'] ; $i++): ?>
        <li <?php if($i == $pagination['active']): ?>class="active"<?php endif; ?>>
             <a href="<?php echo e($pagination['url'].$i. $query_string); ?>"><?php echo e($i); ?></a>
        </li>
        <?php endfor; ?>
        <?php else: ?>
        <?php for($i = $pagination['active'] - 2,$end = $pagination['active'] + 2; $i <= $end ; $i++): ?>
        <li <?php if($i == $pagination['active']): ?>class="active"<?php endif; ?>>
             <a href="<?php echo e($pagination['url'].$i. $query_string); ?>"><?php echo e($i); ?></a>
        </li>
        <?php endfor; ?>
        <?php endif; ?>
        <?php endif; ?>
        <?php if($pagination['count'] != $pagination['active']): ?>
        <li>
            <a href="<?php echo e($pagination['url'] . ($pagination['active'] + 1). $query_string); ?>"><span>&rsaquo;</span></a>
        </li>
        <li>
            <a href="<?php echo e($pagination['url'] .($pagination['count'] . $query_string)); ?>"><span>&raquo;</span></a>
        </li>
        <?php endif; ?>
    </ul>
</div>
<?php endif; ?>

<!--End Pagination--> 