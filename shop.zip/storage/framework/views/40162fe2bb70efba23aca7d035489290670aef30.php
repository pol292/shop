<!--Pagination--> 
<?php if(!empty($pagination['count']) && $pagination['count'] > 1): ?>
<div class="text-center">

    <ul class="pagination">
        <?php if($pagination['active'] != 1): ?>
        <li>
            <a href="<?php echo e($pagination['url'] .'1'); ?>"><span>&laquo;</span></span></a>
        </li>
        <li>
            <a href="<?php echo e($pagination['url'] . ($pagination['active'] - 1)); ?>"><span>&lsaquo;</span></span></a>
        </li>
        <?php endif; ?>
        <?php if($pagination['active']): ?>

        <?php if($pagination['active'] < 3): ?>
        <?php for($i = 1, $end = (($pagination['count'] > 5)? 5 : $pagination['count']); $i <= $end ; $i++): ?>
        <li <?php if($i == $pagination['active']): ?>class="active"<?php endif; ?>>
             <a href="<?php echo e($pagination['url'].$i); ?>"><?php echo e($i); ?></a>
        </li>
        <?php endfor; ?>
        <?php elseif($pagination['active'] >= ($pagination['count'] - 2) ): ?>
        <a href="pagination.blade.php"></a>
        <?php for($i = ($pagination['count'] - 5 > 0)? $pagination['count'] - 5 :1; $i <= $pagination['count'] ; $i++): ?>
        <li <?php if($i == $pagination['active']): ?>class="active"<?php endif; ?>>
             <a href="<?php echo e($pagination['url'].$i); ?>"><?php echo e($i); ?></a>
        </li>
        <?php endfor; ?>
        <?php else: ?>
        <?php for($i = $pagination['active'] - 2,$end = $pagination['active'] + 2; $i <= $end ; $i++): ?>
        <li <?php if($i == $pagination['active']): ?>class="active"<?php endif; ?>>
             <a href="<?php echo e($pagination['url'].$i); ?>"><?php echo e($i); ?></a>
        </li>
        <?php endfor; ?>
        <?php endif; ?>
        <?php endif; ?>
        <?php if($pagination['count'] != $pagination['active']): ?>
        <li>
            <a href="<?php echo e($pagination['url'] . ($pagination['active'] + 1)); ?>"><span>&rsaquo;</span></a>
        </li>
        <li>
            <a href="<?php echo e($pagination['url'] .($pagination['count'])); ?>"><span>&raquo;</span></a>
        </li>
        <?php endif; ?>
    </ul>
</div>
<?php endif; ?>

<!--End Pagination--> 