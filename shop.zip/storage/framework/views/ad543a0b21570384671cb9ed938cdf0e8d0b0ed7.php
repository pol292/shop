<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="container m-t-2">
    <div class="row">

        <!-- Vertical Menu -->
        <div class="col-md-3 m-b-1">
            <div class="title"><span>Categories</span></div>
            <nav class="sidebar-nav">
                <ul class="metismenu vertical-menu">
                    <?php if(empty($categories)): ?>
                    <li><a class="active">No categories in system</a></li>
                    <?php else: ?>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(url("shop/{$categorie['url']}")); ?>">
                            <?php echo e($categorie['title']); ?>

                        </a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(url("shop/sale")); ?>" class="text-center">
                            <span class="label label-danger arrowed-right pull-left">Up to <?php echo e(ceil($max_discount)); ?>%</span>
                            <strong>Sale</strong>
                            <span class="label label-danger arrowed pull-right">Up to <?php echo e(ceil($max_discount)); ?>%</span>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>

            <div class="m-t-3">
                <div class="title"><span>New Arrivals</span></div>
                <?php if(!empty($new_product)): ?>
                <div class="widget-slider owl-carousel owl-theme owl-controls-top-offset m-b-2">
                    <?php $__currentLoopData = $new_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="box-product-outer">
                        <div class="box-product">
                            <div class="img-wrapper">
                                <a href="<?php echo e(url("shop/{$new['category']['url']}/{$new['url']}")); ?>">
                                    <img alt="Product" src="<?php echo e(asset("images/up/{$new['image']}")); ?>">
                                </a>
                                <div class="tags tags-left">
                                    <span class="label-tags"><a href="<?php echo e(url("shop/{$new['category']['url']}/{$new['url']}")); ?>"><span class="label label-success arrowed-right">New Arrivals</span></a></span>
                                </div>
                                <?php if(!empty($new['sale'])): ?>
                                <div class="tags">
                                    <span class="label-tags">
                                        <a href="<?php echo e(url("shop/{$new['category']['url']}/{$new['url']}")); ?>">
                                            <span class="label label-default arrowed">-<?php echo e($new['sale']['discount']); ?>%</span>
                                        </a>
                                    </span>
                                    <span class="label-tags">
                                        <a href="<?php echo e(url("shop/{$new['category']['url']}/{$new['url']}")); ?>">
                                            <span class="label label-<?php echo e($new['sale']['color']); ?> arrowed">Sale</span>
                                        </a>
                                    </span>
                                </div>
                                <?php endif; ?>
                                <div class="option">
                                    <a href="#" data-toggle="tooltip" title="Add to Cart"><i class="fa fa-shopping-cart"></i></a>
                                    <a href="#" data-toggle="tooltip" title="Add to Compare"><i class="fa fa-align-left"></i></a>
                                    <a href="#" data-toggle="tooltip" title="Add to Wishlist" class="wishlist"><i class="fa fa-heart"></i></a>
                                </div>
                            </div>
                            <h6><a href="<?php echo e(url("shop/{$new['category']['url']}/{$new['url']}")); ?>">WranglerGrey Printed Slim Fit Round Neck T-Shirt</a></h6>
                            <?php if(empty($new['sale'])): ?>
                            <div>$<?php echo e($new['price']); ?> </div>
                            <?php else: ?>
                            <div class="price">
                                <div>
                                    $<?php echo e($new['price']*(1-$new['sale']['discount']/100)); ?> 
                                    <span class="label-tags">
                                        <span class="label label-default">-<?php echo e($new['sale']['discount']); ?>%</span>
                                    </span>
                                </div>
                                <span class="price-old">$<?php echo e($new['price']); ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php endif; ?>
            </div>
        </div>
        <!-- End Vertical Menu -->

        <div class="clearfix visible-sm visible-xs"></div>

        <div class="col-md-9">

            <!-- Featured -->
            <div class="title"><span>Sale</span></div>
            <?php if(!empty($sale_product)): ?>
            <?php $__currentLoopData = $sale_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xs-6 col-sm-4 col-lg-3 box-product-outer">
                <div class="box-product">
                    <div class="img-wrapper">
                        <a href="<?php echo e(url("shop/{$sale['category']['url']}/{$sale['url']}")); ?>">
                            <img alt="Product" src="<?php echo e(asset("images/up/{$sale['image']}")); ?>">
                        </a>
                        <?php if(!empty($sale['sale'])): ?>
                        <div class="tags">
                            <span class="label-tags">
                                <a href="<?php echo e(url("shop/{$sale['category']['url']}/{$sale['url']}")); ?>">
                                    <span class="label label-default arrowed">-<?php echo e($sale['sale']['discount']); ?>%</span>
                                </a>
                            </span>
                        </div>
                        <div class="tags tags-left">
                            <span class="label-tags">
                                <a href="<?php echo e(url("shop/{$sale['category']['url']}/{$sale['url']}")); ?>">
                                    <span class="label label-<?php echo e($sale['sale']['color']); ?> arrowed-right">Sale</span>
                                </a>
                            </span>
                        </div>
                        <?php endif; ?>
                        <div class="option">
                            <a href="#" data-toggle="tooltip" title="Add to Cart"><i class="fa fa-shopping-cart"></i></a>
                            <a href="#" data-toggle="tooltip" title="Add to Compare"><i class="fa fa-align-left"></i></a>
                            <a href="#" data-toggle="tooltip" title="Add to Wishlist" class="wishlist"><i class="fa fa-heart"></i></a>
                        </div>
                    </div>
                    <h6><a href="<?php echo e(url("shop/{$sale['category']['url']}/{$sale['url']}")); ?>"><?php echo e($sale['title']); ?></a></h6>
                    <?php if(empty($sale['sale'])): ?>
                        <div>$<?php echo e($sale['price']); ?> </div>
                        <?php else: ?>
                        <div class="price">
                            <div>
                                $<?php echo e($sale['price']*(1-$sale['sale']['discount']/100)); ?> 
                                <span class="label-tags">
                                    <span class="label label-default">-<?php echo e($sale['sale']['discount']); ?>%</span>
                                </span>
                            </div>
                            <span class="price-old">$<?php echo e($sale['price']); ?></span>
                        </div>
                        <?php endif; ?>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-half-o"></i>
                        <a href="#">(5 reviews)</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <!-- End Featured -->
            <div class="clearfix <?php if(!empty($sale_product) && count($sale_product) == 4): ?> visible-sm visible-xs <?php endif; ?>"></div>


            <!-- Collection -->
            <div class="title m-t-2"><span>Random Items</span></div>
            <div class="product-slider owl-carousel owl-theme owl-controls-top-offset">
                <?php if(!empty($random_list_product)): ?>
                <?php $__currentLoopData = $random_list_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $random): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="box-product-outer">
                    <div class="box-product">
                        <div class="img-wrapper">
                            <a href="<?php echo e(url("shop/{$random['category']['url']}/{$random['url']}")); ?>">
                                <img alt="Product" src="<?php echo e(asset("images/up/{$random['image']}")); ?>">
                            </a>
                            <?php if(!empty($random['sale'])): ?>
                            <div class="tags">
                                <span class="label-tags">
                                    <a href="<?php echo e(url("shop/{$random['category']['url']}/{$random['url']}")); ?>">
                                        <span class="label label-default arrowed">-<?php echo e($new['sale']['discount']); ?>%</span>
                                    </a>
                                </span>
                                <span class="label-tags">
                                    <a href="<?php echo e(url("shop/{$random['category']['url']}/{$random['url']}")); ?>">
                                        <span class="label label-<?php echo e($new['sale']['color']); ?> arrowed">Sale</span>
                                    </a>
                                </span>
                            </div>
                            <?php endif; ?>
                            <div class="option">
                                <a href="#" data-toggle="tooltip" title="Add to Cart"><i class="fa fa-shopping-cart"></i></a>
                                <a href="#" data-toggle="tooltip" title="Add to Compare"><i class="fa fa-align-left"></i></a>
                                <a href="#" data-toggle="tooltip" title="Add to Wishlist" class="wishlist"><i class="fa fa-heart"></i></a>
                            </div>
                        </div>
                        <h6>
                            <a href="<?php echo e(url("shop/{$random['category']['url']}/{$random['url']}")); ?>">
                                PhosphorusGrey Melange Printed V Neck T-Shirt
                            </a>
                        </h6>
                        <?php if(empty($random['sale'])): ?>
                        <div>$<?php echo e($random['price']); ?> </div>
                        <?php else: ?>
                        <div class="price">
                            <div>
                                $<?php echo e($random['price']*(1-$random['sale']['discount']/100)); ?> 
                                <span class="label-tags">
                                    <span class="label label-default">-<?php echo e($random['sale']['discount']); ?>%</span>
                                </span>
                            </div>
                            <span class="price-old">$<?php echo e($random['price']); ?></span>
                        </div>
                        <?php endif; ?>
                        <div class="rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star-half-o"></i>
                            <i class="fa fa-star-o"></i>
                            <a href="#">(5 reviews)</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <!-- End Collection -->

        </div>

    </div>
</div>
<!-- End Main Content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>