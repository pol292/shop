<div class="box-product">
    <?php echo $__env->make('shop.skin.product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>