<?php $__env->startSection('add_page'); ?>
<div class="form-group">
    <a class="btn btn-primary" href="<?php echo e(url('dashboard/CMS/page/create')); ?>" data-toggle="tooltip" data-placement="top" title="Add">
        <span class="fa fa-plus"></span> Add page
    </a>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->yieldContent('add_page'); ?>
<?php if(!empty($cms_pages)): ?>

<table class="table">
    <tr>
        <th class="text-center">Active</th>
        <th>Title</th>
        <th>URL</th>
        <th>Created at</th>
        <th>Updated at</th>
        <th>Actions</th>
    </tr>
    <?php $__currentLoopData = $cms_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cms_page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td class="text-center"><span class="fa fa-<?php echo e($cms_page['active']? 'check text-success' : 'times text-danger'); ?>"</td>
        <td><?php echo e($cms_page['title']); ?></td>
        <td><?php echo e($cms_page['url']); ?></td>
        <td><?php echo e($cms_page['created_at']); ?></td>
        <td><?php echo e($cms_page['updated_at']); ?></td>
        <td>
            <div class="btn-group btn-group-xs" role="group">
                <a href="<?php echo e(url('dashboard/CMS/page/' . $cms_page['url'])); ?>" class="btn btn-xs btn-default" data-toggle="tooltip" data-placement="top" title="View"><span class="fa fa-eye"></span></a>
                <a href="<?php echo e(url('dashboard/CMS/page/'.$cms_page['id']) .'/edit'); ?>" class="btn btn-xs btn-default" data-toggle="tooltip" data-placement="top" title="Edit">
                    <span class="fa fa-edit"></span>
                </a>
                <a href="#" class="btn btn-xs btn-danger" data-toggle="modal" data-target="#delete" data-route="<?php echo e('dashboard/CMS/page/' . $cms_page['id']); ?>" data-msg="Did you want to delete (<?php echo e($cms_page['title']); ?>) page">
                    <span class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="Delete"></span>
                </a>
            </div>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <th class="text-center">Active</th>
        <th>Title</th>
        <th>URL</th>
        <th>Created at</th>
        <th>Updated at</th>
        <th>Actions</th>
    </tr>
</table>
<?php else: ?>
<div class="alert alert-warning">
    You are not have pages in your CMS system
</div>
<?php endif; ?>
<?php echo $__env->yieldContent('add_page'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>