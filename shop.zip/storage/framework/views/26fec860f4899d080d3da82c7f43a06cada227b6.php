<?php $__env->startSection('content'); ?>
<table class="table">
    <tr>
        <th>Title</th>
        <th>URL</th>
        <th>Created at</th>
        <th>Updated at</th>
        <th>Actions</th>
    </tr>
    <?php $__currentLoopData = $cms_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cms_page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($cms_page['title']); ?></td>
            <td><?php echo e($cms_page['url']); ?></td>
            <td><?php echo e($cms_page['created_at']); ?></td>
            <td><?php echo e($cms_page['updated_at']); ?></td>
            <td>
                <a href="<?php echo e(url('dashboard/CMS/page/'.$cms_page['id'])); ?>" class="btn btn-xs btn-primary">
                    <span class="glyphicon glyphicon-pencil"></span>
                </a> 
                | Delete
                | View
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>