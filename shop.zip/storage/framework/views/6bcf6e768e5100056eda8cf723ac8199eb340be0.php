<div class="col-xs-6 col-sm-4 col-lg-3 box-product-outer">
    <div class="box-product">
        <?php echo $__env->make('shop.skin.product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>