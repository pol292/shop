<?php $__env->startSection('content'); ?>
<?php if(!empty($historys)): ?>

<table class="table">
    <tr>
        <th>Change</th>
        <th>Description</th>
        <th>Updated at</th>
        <th class="text-center">Actions</th>
    </tr>
    <?php $__currentLoopData = $historys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php if(!empty($history['icon'])): ?><span class="fa fa-<?php echo e($history['icon']); ?>"></span><?php endif; ?> &nbsp; <?php echo e(ucfirst($history['change'])); ?></td>
        <td><?php echo e($history['description']); ?></td>
        <td><?php echo e($history['updated_at']); ?></td>
        <td class="text-center">
            <a href="<?php echo e(url('dashboard/restore/'.$history['id'])); ?>" class="btn btn-xs btn-default" data-toggle="tooltip" data-placement="top" title="Restore">
                <span class="fa fa-history"></span>
            </a> 
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <th>Change</th>
        <th>Description</th>
        <th>Updated at</th>
        <th class="text-center">Actions</th>
    </tr>
    
</table>
<?php else: ?>
<p>You Are not have backup for <?php echo e($type); ?></p>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>