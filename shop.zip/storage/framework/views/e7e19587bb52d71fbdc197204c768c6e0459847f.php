<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="container m-t-3">
    <div class="row">

        <!-- Image List -->
        <div class="col-sm-4">
            <?php if(empty($product['image'])): ?>
            <div class="image-detail">
                <img src="<?php echo e(asset('images/empty.png')); ?>" alt="Empty image">
            </div>
            <?php else: ?>
            <div class="image-detail">
                <img src="<?php echo e(asset("images/up/{$product['image']}")); ?>" data-zoom-image="<?php echo e(asset("images/up/{$product['image']}")); ?>" alt="<?php echo e($product['title']); ?>">
            </div>
            <?php if(count($product['images']) > 1): ?>
            <div class="products-slider-detail owl-carousel owl-theme m-b-2">
                <a href="#">
                    <img src="<?php echo e(asset("images/up/{$product['image']}")); ?>" data-zoom-image="<?php echo e(asset("images/up/{$product['image']}")); ?>" alt="<?php echo e($product['title']); ?>" class="img-thumbnail">
                </a>
                <?php $__currentLoopData = $product['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($image != $product['image'] ): ?>
                <a href="#">
                    <img src="<?php echo e(asset("images/up/{$image}")); ?>"  data-zoom-image="<?php echo e(asset("images/up/{$image}")); ?>" alt="<?php echo e($product['title']); ?>" class="img-thumbnail">
                </a>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <?php endif; ?>

            <div class="title"><span>Share to</span></div>
            <div class="share-button m-b-3">
                <button type="button" class="btn btn-primary"><i class="fa fa-facebook"></i></button>
                <button type="button" class="btn btn-info"><i class="fa fa-twitter"></i></button>
                <button type="button" class="btn btn-danger"><i class="fa fa-google-plus"></i></button>
                <button type="button" class="btn btn-primary"><i class="fa fa-linkedin"></i></button>
                <button type="button" class="btn btn-warning"><i class="fa fa-envelope"></i></button>
            </div>
        </div>
        <!-- End Image List -->

        <div class="col-sm-8">
            <div class="title-detail"><?php echo e($product['title']); ?></div>
            <form method="post" action="<?php echo e(url('shop/checkout/'.$product['url'] )); ?>">
                <?php echo e(csrf_field()); ?>

                <table class="table table-detail">
                    <tbody>
                        <tr>
                            <td>Price</td>
                            <td>
                                <?php if(empty((float) $product['sale'])): ?>
                                <div>$<?php echo e($product['price']); ?> </div>
                                <?php else: ?>
                                <div class="price">
                                    <div>
                                        $<?php echo e($product['price']*(1-$product['sale']/100)); ?> 
                                        <span class="label-tags">
                                            <span class="label label-default">-<?php echo e($product['sale']); ?>%</span>
                                        </span>
                                    </div>
                                    <span class="price-old">$<?php echo e($product['price']); ?></span>
                                </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Availability</td>
                            <td>
                                <?php if(empty($product['stock'])): ?>
                                <span class="label label-danger"><s>Out of Stock</s></span>
                                <?php elseif($product['stock'] == 1): ?>
                                <span class="label label-warning">Last 1 Ready in Stock</span>
                                <?php elseif($product['stock'] > 1): ?>
                                <span class="label label-success"><?php echo e($product['stock']); ?> Ready in Stock</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>In cart</td>
                            <td>
                                <?php if(!empty($cart)): ?>
                                <span class="label label-default"><?php echo e($cart['qty']); ?> in your cart</span>
                                <?php else: ?>
                                <span class="label label-danger">0 in your cart</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Quantity</td>
                            <td>

                                <div class="input-qty">
                                    <input type="text" data-bts-max="<?php echo e($product['stock']); ?>" id='qty' value="1" class="form-control text-center" name="qty"/>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <td></td>
                            <td>
                                <button class="addMenyToCart btn btn-theme m-b-1" type="button" data-id='<?php echo e($product['id']); ?>'><i class="fa fa-shopping-cart"></i> Add to Cart</button>
                                <i class="fa fa-spinner rotating" aria-hidden="true" style="color:#000;display: none; font-size: 30px; margin-right: 10px; "></i>
                                <button type="submit" class="btn btn-theme m-b-1"><i class="fa fa-check"></i> Checkout</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>

        </div>

        <div class="col-md-8">

            <!-- Nav tabs -->
            <ul class="nav nav-tabs" role="tablist">
                <li role="presentation" class="active"><a href="#desc" aria-controls="desc" role="tab" data-toggle="tab">Description</a></li>
                <li role="presentation"><a href="#review" aria-controls="review" role="tab" data-toggle="tab">Reviews (<?php echo e(count($product['rates'])); ?>)</a></li>
            </ul>
            <!-- End Nav tabs -->

            <!-- Tab panes -->
            <div class="tab-content tab-content-detail">

                <!-- Description Tab Content -->
                <div role="tabpanel" class="tab-pane active" id="desc">
                    <div class="well">
                        <p>
                            <?php echo e($product['article']); ?>

                        </p>
                    </div>
                </div>
                <!-- End Description Tab Content -->

                <!-- Review Tab Content -->
                <div role="tabpanel" class="tab-pane" id="review">
                    <div class="well">
                        <?php if(empty($product['rates'])): ?>
                        <div class="alert alert-warning">In currently product don't have a reviews.</div>
                        <?php else: ?>
                        <div style="overflow-y: auto; max-height: 200px;">
                            <?php $__currentLoopData = $product['rates']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="media">
                                <div class="media-body">
                                    <div class="row">
                                        <div class="col-md-10">
                                            <h5 class="media-heading"><strong><?php echo e($rate['user']['name']); ?></strong></h5>
                                        </div>
                                        <div class="col-md-2 product-rating">
                                            <?php for($i = 0; $i < 5; $i++ , $rate['rate']--): ?>
                                            <?php if($rate['rate'] >= 1): ?>
                                            <i class="fa fa-star"></i>
                                            <?php elseif($rate['rate'] === 0.5): ?>
                                            <i class="fa fa-star-half-o"></i>
                                            <?php else: ?>
                                            <i class="fa fa-star-o"></i>
                                            <?php endif; ?>
                                            <?php endfor; ?>
                                        </div>
                                    </div>
                                    <?php echo e($rate['review']); ?>

                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>
                        <?php if(!empty($user_id)): ?>
                        <hr/>
                        <h4 class="m-b-2">Add your review</h4>
                        <form role="form" method="post" action="<?php echo e(url('shop/add-rate')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="user_id" value="<?php echo e($user_id); ?>">
                            <input type="hidden" name="product_id" value="<?php echo e($product['id']); ?>">
                            <input type="hidden" name="back" value="<?php echo e($back); ?>">
                            <div class="form-group">
                                <label>Rating</label><div class="clearfix"></div>
                                <div class="input-rating"></div>
                            </div>
                            <div class="form-group">
                                <label for="Review">Your Review</label>
                                <textarea id="Review" class="form-control" rows="5" placeholder="Your Review" name='review'></textarea>
                            </div>
                            <button type="submit" class="btn btn-theme">Submit Review</button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- End Review Tab Content -->

            </div>
            <!-- End Tab panes -->

        </div>
    </div>

    <!-- Related Products -->
    <div class="row m-t-3">
        <div class="col-xs-12">
            <div class="title"><span>Products you will love</span></div>
            <div class="related-product-slider owl-carousel owl-theme owl-controls-top-offset">
                <?php echo $__env->renderEach('shop.skin.product_slider', $random_list_product, 'product'); ?>
            </div>
        </div>
    </div>
    <!-- End Related Products -->
</div>

<!-- End Main Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>