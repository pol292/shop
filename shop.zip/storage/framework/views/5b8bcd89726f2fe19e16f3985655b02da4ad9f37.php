<?php $__env->startSection('content'); ?>

<div class="panel panel-primary">
    <div class="panel-heading">
        Add Page
    </div>
    <div class="panel-body">
        <form action="<?php echo e(url('dashboard/CMS/page')); ?>" method="post">
            <?php echo e(csrf_field()); ?>


            <div class="form-group">
                <label for="title">Page Title:</label>
                <input type="text" name="title" id="title" class="form-control friendly-url" value="<?php echo e(old('title')); ?>">
            </div>
            <div class="form-group">
                <label for="url">Page Url:</label>
                <input type="text" name="url" id="url" class="form-control friendly-url-paste" value="<?php echo e(old('url')); ?>">
            </div>
            <div class="form-group">
                <label for="article">Article:</label>
                <textarea id="article" name="article" class="summernote"><?php echo e(old('article')); ?></textarea>
            </div>
            <div class="checkbox">
                <strong>Page activation:</strong>
                <label>
                    <input type="checkbox" name="active" <?php if(old('active')): ?> checked="checked" <?php endif; ?>>
                           Active
                </label>
            </div>

            <a href="<?php echo e(url('dashboard/CMS/page')); ?>" class="btn btn-danger pull-left edit-page-btn">Cancel</a>
            <input class="btn btn-primary pull-right" type="submit" value="Save change">
            <div class="clearfix"></div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>