<?php $__env->startSection('content'); ?>
    <?php if($contents): ?>
        <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <<?php echo e($content['tag']); ?>><?php echo e($content['title']); ?></<?php echo e($content['tag']); ?>>
            <p><?php echo $content['article']; ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>page not found</p>
    <?php endif; ?>
    <?php if(!empty($back)): ?>
    <div class="preview" style="">
        <h2><small>This is preview mode</small></h2>
        <a href="<?php echo e($back); ?>" class="btn btn-primary">Back to dashboard</a>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>