<?php $__env->startSection('content'); ?>
<!-- Main Content -->

<div class="row">

    <!-- Shopping Cart List -->
    <div class="col-md-9">
        <div class="title"><span>My Shopping Cart</span></div>
        <div id='cart-show' class="table-responsive">
            <?php if(Cart::count()): ?>
            <table class="table table-bordered table-cart">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Description</th>
                        <th>Quantity</th>
                        <th>Unit price</th>
                        <th>SubTotal</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = Cart::content()->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inCart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="img-cart">
                            <a href="<?php echo e($inCart['options']['url']); ?>">
                                <img alt="Product" src="<?php echo e(asset("images/up/{$inCart['options']['image']}")); ?>" class="img-thumbnail">
                            </a>
                        </td>
                        <td style="vertical-align: middle;">
                            <p><a href="<?php echo e($inCart['options']['url']); ?>" class="d-block"><?php echo e($inCart['name']); ?></a></p>
                        </td>
                        <td class="input-qty"><input type="text" value="<?php echo e($inCart['qty']); ?>" data-rowid='<?php echo e($inCart['rowId']); ?>' class="form-control text-center cart-qty" /></td>
                        <td class="unit text-center" style="vertical-align: middle;">$<?php echo e(round($inCart['price'],2)); ?></td>
                        <td class="sub text-center" style="vertical-align: middle;">$<?php echo e(round($inCart['subtotal'],2)); ?></td>
                        <td class="action text-center" style="vertical-align: middle;">
                            <a href="#" class="text-danger remove-from-cart" data-rowid="<?php echo e($inCart['rowId']); ?>" data-toggle="tooltip" data-placement="top" data-original-title="Remove"><i class="fa fa-trash-o"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="4" class="text-right">Total</td>
                        <td colspan="2"><b>$<?php echo e(Cart::total()); ?></b></td>
                    </tr>
                </tbody>
            </table>
            <?php else: ?>
            <div class="alert alert-warning">
                Don't have products in cart
            </div>
            <?php endif; ?>
        </div>
        <nav aria-label="Shopping Cart Next Navigation">
            <ul class="pager">
                <li class="previous"><a href="<?php echo e(url('/')); ?>"><span aria-hidden="true">&larr;</span> Continue Shopping</a></li>
                <li class="next"><a href="<?php echo e(url('shop/checkout')); ?>">Proceed to Checkout <span aria-hidden="true">&rarr;</span></a></li>
            </ul>
        </nav>
    </div>
    <!-- End Shopping Cart List -->

    <!-- New Arrivals -->
    <div class="col-md-3 hidden-sm hidden-xs">
        <div class="title"><span>New Arrivals <i class="fa fa-chevron-circle-right"></i></span></div>
        <div class="widget-slider owl-carousel owl-theme owl-controls-top-offset">
            <?php echo $__env->renderEach('shop.skin.product_slider', $new_product, 'product'); ?>
        </div>
    </div>
    <!-- End New Arrivals -->

</div>

<!-- End Main Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>