<?php $__env->startSection('content'); ?>
<div class="form-group">
</div>

<?php if(!empty($advertisings)): ?>
<form method="GET" action="" style="margin-bottom: 15px;">
    <div class="input-group">
        <div class="input-group-btn">
            <a class="btn btn-primary" href="<?php echo e(url('dashboard/advertisings/create')); ?>" data-toggle="tooltip" data-placement="top" title="Add Advertising">
                <span class="fa fa-plus"></span> Advertising
            </a>
            <?php if(!empty($request->find)): ?>
            <a href="<?php echo e(url('dashboard/advertisings')); ?>" type="submit" class="btn btn-default" data-toggle="tooltip" data-placement="top" title="Clear Search"><i class="fa fa-close"></i></a>
            <?php endif; ?>
        </div>
        <input type="text" name="find" class="form-control search-input" aria-label="Search here..." placeholder="Search here..." autocomplete="off" value="<?php echo e($request->find); ?>">
        <div class="input-group-btn">
            <button type="submit" class="btn btn-primary"  data-toggle="tooltip" data-placement="top" title="Search"><i class="fa fa-search"></i></button>
        </div>
    </div>
</form>

<table class="table">
    <tr>
        <th>Title</th>
        <th>URL</th>
        <th>Created at</th>
        <th>Updated at</th>
        <th>Actions</th>
    </tr>
    <?php $__currentLoopData = $advertisings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($adv['title']); ?></td>
        <td><?php echo e($adv['url']); ?></td>
        <td><?php echo e($adv['created_at']); ?></td>
        <td><?php echo e($adv['updated_at']); ?></td>
        <td>
            <div class="btn-group btn-group-xs" role="group">
                <a href="<?php echo e(url('dashboard/advertisings/'.$adv['id']) .'/edit'); ?>" class="btn btn-xs btn-default" data-toggle="tooltip" data-placement="top" title="Edit">
                    <span class="fa fa-edit"></span>
                </a>
                <a href="#" class="btn btn-xs btn-danger" data-toggle="modal" data-target="#delete" data-route="<?php echo e('dashboard/advertisings/' . $adv['id']); ?>" data-msg="Did you want to delete (<?php echo e($adv['title']); ?>) category">
                    <span class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="Delete"></span>
                </a>
            </div>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <th>Title</th>
        <th>URL</th>
        <th>Created at</th>
        <th>Updated at</th>
        <th>Actions</th>
    </tr>
</table>
<?php else: ?>
<div class="alert alert-warning">
    You are not have pages in your CMS system
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>