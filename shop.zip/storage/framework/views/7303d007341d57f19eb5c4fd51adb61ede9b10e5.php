<?php $__env->startSection('content'); ?>

<div class="row cf nestable-lists">

    <div class="panel panel-primary">
        <div class="panel-heading">
            Edit Menu
        </div>
        <div class="panel-body">
            <div class="dd col-md-6" id="nestable" style="border-right: 1px solid rgba(230,230,230,0.5);">
                <h2>Current Menu</h2>
                <ol class="dd-list <?php if(empty($menu)): ?> dd-empty <?php endif; ?>">
                    <?php if(empty($menu)): ?>
                    <li class="dd-item list-group-item list-group-item-warning" style="padding: 7px; width: 100%; height: 150px;">
                        Empty menu
                    </li>
                    <?php else: ?>
                    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="dd-item" data-id="<?php echo e($item['id']); ?>" data-page-id="<?php echo e($item['pages']['id']); ?>">
                        <div class="dd-handle">
                            <?php echo e($item['pages']['title']); ?><?php if($item['pages']['active']): ?>
                            <span class="pull-right fa fa-eye"></span><?php endif; ?>
                        </div>
                        <?php if(!empty($item['sub_menu'])): ?>
                        <ol class="dd-list">
                            <?php $__currentLoopData = $item['sub_menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="dd-item" data-id="<?php echo e($sub_page['id']); ?>" data-page-id="<?php echo e($sub_page['pages']['id']); ?>">
                                <div class="dd-handle">
                                    <?php echo e($sub_page['pages']['title']); ?>

                                    <?php if($sub_page['pages']['active']): ?><span class="pull-right fa fa-eye"></span><?php endif; ?>
                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>
                        <?php endif; ?>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ol>
            </div>

            <div class="dd col-md-6" id="nestable2" style="border-left: 1px solid rgba(230,230,230,0.5);">
                <h2>Pages list</h2>
                <ol class="dd-list <?php if(empty($pages)): ?> dd-empty <?php endif; ?>">
                    <?php if(empty($pages)): ?>
                    <li class="dd-item list-group-item list-group-item-warning" style="padding: 7px; width: 100%; height: 150px;">
                        Empty page
                    </li>

                    <?php else: ?>
                    <input type="text" class="search-page form-control" placeholder="Search page...">
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="dd-item" data-id='' data-page-id="<?php echo e($p['id']); ?>">
                        <div class="dd-handle">
                            <?php echo e($p['title']); ?>

                            <?php if($p['active']): ?><span class="pull-right fa fa-eye"></span><?php endif; ?>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ol>
            </div>

        </div>    
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>