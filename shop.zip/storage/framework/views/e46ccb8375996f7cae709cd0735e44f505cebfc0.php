<?php 
$color = ['danger', 'success', 'info', 'primary'];
 ?>
<div class="img-wrapper">

    <?php if(empty($product['image'])): ?>
    <a href="<?php echo e(url("shop/{$product['category']['url']}/{$product['url']}")); ?>">
        <img src="<?php echo e(asset('images/empty.png')); ?>" alt="Empty image">
    </a>
    <?php else: ?>
    <a href="<?php echo e(url("shop/{$product['category']['url']}/{$product['url']}")); ?>">
        <img alt="<?php echo e($product['title']); ?>" src="<?php echo e(asset("images/up/{$product['image']}")); ?>" height="150">
    </a>
    <?php endif; ?>
    <?php if(!empty((float) $product['sale'])): ?>
    <div class="tags">
        <span class="label-tags">
            <?php if($product['stock'] == 0): ?>
            <a href="<?php echo e(url("shop/{$product['category']['url']}/{$product['url']}")); ?>">
                <span class="label label-danger arrowed">Out of Stock</span>
            </a>
            <?php endif; ?>
        </span>
        <span class="label-tags">
            <a href="<?php echo e(url("shop/{$product['category']['url']}/{$product['url']}")); ?>">
                <span class="label label-default arrowed">-<?php echo e($product['sale']); ?>%</span>
            </a>
        </span>
    </div>
    <div class="tags tags-left">
        <span class="label-tags">
            <?php if($product['stock'] == 0): ?>
            <a href="<?php echo e(url("shop/{$product['category']['url']}/{$product['url']}")); ?>">
                <span class="label label-danger arrowed-right">Out of Stock</span>
            </a>
            <?php endif; ?>
        </span>
        <span class="label-tags">
            <a href="<?php echo e(url("shop/{$product['category']['url']}/{$product['url']}")); ?>">
                <span class="label label-<?php echo e($color[array_rand($color)]); ?> arrowed-right">Sale</span>
            </a>
        </span>
    </div>
    <?php endif; ?>

    <div class="option">
        <a href="#" data-toggle="tooltip" title="Add to Cart" class="addToCart" data-pid="<?php echo e($product['id']); ?>"><i class="fa fa-shopping-cart"></i></a>
        <i class="fa fa-spinner rotating" aria-hidden="true" style="color:#fff;display: none;"></i>
    </div>
</div>
<h6><a href="<?php echo e(url("shop/{$product['category']['url']}/{$product['url']}")); ?>"><?php echo e($product['title']); ?></a></h6>
<?php if(empty((float) $product['sale'])): ?>
<div>$<?php echo e($product['price']); ?> </div>
<?php else: ?>
<div class="price">
    <div>
        $<?php echo e($product['price']*(1-$product['sale']/100)); ?> 
        <span class="label-tags">
            <span class="label label-default">-<?php echo e($product['sale']); ?>%</span>
        </span>
    </div>
    <span class="price-old">$<?php echo e($product['price']); ?></span>
</div>
<?php endif; ?>
<?php if(!empty($product['rates'])): ?>
<div class="rating">
    <?php for($i = 0 , $rate= collect($product['rates'])->avg('rate'); $i < 5; $i++ , $rate--): ?>
    <?php if($rate >= 1): ?>
    <i class="fa fa-star"></i>
    <?php elseif($rate === 0.5): ?>
    <i class="fa fa-star-half-o"></i>
    <?php else: ?>
    <i class="fa fa-star-o"></i>
    <?php endif; ?>
    <?php endfor; ?>
    <a href="<?php echo e(url("shop/{$product['category']['url']}/{$product['url']}")); ?>">(<?php echo e(count($product['rates'])); ?> reviews)</a>

</div>
<?php endif; ?>