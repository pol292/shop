    
<?php $__env->startSection('btns'); ?>
<div style="margin: 15px 0;">
    <a href="<?php echo e(url("dashboard/restore/history/$back")); ?>" class="btn btn-default pull-left" data-toggle="tooltip" data-placement="top" title="Back">
        <span class="fa fa-arrow-left"></span> Back
    </a>
    <?php if(!empty($differences)): ?>
    <a href="<?php echo e(url('dashboard/restore/'.$id)); ?>" class="btn btn-primary pull-right" data-toggle="tooltip" data-placement="top" title="Restore">
        <span class="fa fa-history"></span> Restore
    </a>
    <?php endif; ?>
    <div class="clearfix"></div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/dashboard/diff.css')); ?>" rel="stylesheet">

<div class="row">
    <?php echo $__env->yieldContent('btns'); ?>
    <?php if(!empty($differences)): ?>
    <div class="panel panel-primary">
        <div class="panel-heading">HTML Difference</div>
        <div class="panel-body" style="padding: 0;">
            <?php echo $differences; ?>

        </div>
    </div>
    <div class="panel panel-primary">
        <div class="panel-heading">View Difference</div>
        <div class="panel-body" style="background-color: #f1f8ff">
            <div class="row">
                <?php if(!empty($diff)): ?>
                <?php $__currentLoopData = $diff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <div class="panel <?php if($key == 'old'): ?> panel-danger <?php else: ?> panel-success <?php endif; ?> ">
                        <div class="panel-heading"><?php echo e(ucfirst($key)); ?></div>
                        <div class="panel-body">
                            <?php echo $p; ?>

                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="alert alert-warning">
        No Different with current version.
    </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('btns'); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>