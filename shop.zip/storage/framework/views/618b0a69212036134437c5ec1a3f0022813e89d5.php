<?php $__env->startSection('content'); ?>
<div class="form-group">
</div>

<a href="<?php echo e(url('dashboard/shop/order')); ?>" class="btn btn-default">Back to orders</a>
<?php if(!empty($order['orders'])): ?>
<table class="table">
    <thead>
        <tr>
            <td></td>
            <td>Product Name</td>
            <td>Qty</td>
            <td>price</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $order['orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><img src="<?php echo e(asset('images/up/'.$item['options']['image'])); ?>" alt="<?php echo e($item['name']); ?>" height="50"></td>
            <td><a href="<?php echo e(url($item['options']['url'])); ?>"><?php echo e($item['name']); ?></span></td>
            <td>
                <?php echo e($item['qty'] . ' item' . ($item['qty'] == 1? '':'s')); ?>

            </td>
            <td><?php echo e($item['price']); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tr>
        <td></td>
        <td>Product Name</td>
        <td>Qty</td>
        <td>price</td>
    </tr>

</table>
<h3>Total: <small>$<?php echo e($order['total']); ?></small></h3>

<?php else: ?>
<div class="alert alert-warning">
    You are not have pages in your CMS system
</div>
<?php endif; ?>
<a href="<?php echo e(url('dashboard/shop/order')); ?>" class="btn btn-default">Back to orders</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>